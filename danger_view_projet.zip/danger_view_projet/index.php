<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dangerviewdb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$query = "UPDATE visite SET vues='vues' + 1 WHERE id='id'"; 
    
$query_run =mysqli_query($conn, $query);

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Inscription</title>
	<link rel="stylesheet" type="text/css" href="stylesss.css">
	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body>
	<body style=" background-image: url(bg.png); background-repeat: repeat;">
  <div class="container" style=" background-image: url(bg.png); background-repeat: repeat;">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Inscription</h5>
            <div class="col text-center ">
            	<img src="avatar.png" class="mb-5 ">
            </div>


         <!-- Alerte -->
            <?php

                if (isset($_POST['inscription'])) {?>
                  
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                  Enregistré avec succes !
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>

            <?php }?>

<!--Début formulaire d'inscription -->



            <form action="" method="POST" class="form-signin">
              <div class="form-label-group">
                <label for="inputNom">Nom & Prénom</label>
                <input type="text" name="nom" id="inputNom" class="form-control" placeholder="Nom & Prénom" required >
              </div>

              <div class="form-label-group">
                <label for="inputEmail">Adresse mail</label>
                <input type="text" name="mail" id="inputEmail" class="form-control" placeholder="Adresse mail" required>
              </div>

              <div class="form-label-group">
                <label for="inputPassword">Mot de passe</label>
                <input type="password" name="mdp" id="inputPassword" class="form-control" placeholder="Mot de passe" required autofocus> 
              </div>

              <div class="form-label-group mb-5">
                <label for="inputFonction">Fonction</label>
                <select name="fnc" class="form-control" id="inputFonction">
                  <option>--Définir une fonction--</option>
                  <option>Administrateur</option>
                  <option>Superviseur</option>
                  <option>Opérateur</option>
                </select>
              </div>

              <button name="inscription" class="btn btn-lg btn-primary btn-block text-uppercase">
              S'inscrire
              </button>
              <hr class="my-4">
              <button class="btn btn-lg btn-primary btn-block text-uppercase badge-warning"> <a href="<?php echo 'login.php' ?>">Se connecter</a></button>
            </form>


<!--Fin formulaire d'inscription -->


          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    <!-- script PHP. ---------------------------------------------------------------- -->


<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dangerviewdb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['inscription'])){
$nom = $_POST['nom'];
$mail = $_POST['mail'];
$mdp = md5($_POST['mdp']);
$fnc = $_POST['fnc'];
$dateinscript = date("Y-m-d");

$sql = "INSERT INTO utilisateurs (nom, mail, mdp, fnc, dateinscript)
VALUES ('$nom', '$mail', '$mdp','$fnc','$dateinscript')";

if (mysqli_query($conn, $sql)) {
  echo "Un utilisateur a été enregistré";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}else{
  echo "saisir les informations de l'utilisateur";
}

mysqli_close($conn);

?>





</body>
</html>


